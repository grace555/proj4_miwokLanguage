package com.example.android.miwok;

public class Word {

    private String mDefautTranslation;
    private String mMiwokTranslation;

    public Word(String defautTranslation, String miwokTranslation){
        mDefautTranslation = defautTranslation;
        mMiwokTranslation = miwokTranslation;
    }

    public String getMiwokTranslation() {
        return mMiwokTranslation;
    }

    public String getDefautTranslation() {
        return mDefautTranslation;
    }
}
